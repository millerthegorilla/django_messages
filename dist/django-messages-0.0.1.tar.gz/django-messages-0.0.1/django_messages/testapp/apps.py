import django


class TestAppConfig(django.apps.AppConfig):
    name = "django_messages.testapp"
    verbose_name = "TestApp"
