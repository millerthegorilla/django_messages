from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = "django_messages.testapp"
    verbose_name = "TestApp"
